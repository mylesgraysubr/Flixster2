package com.example.flixsterpart2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.example.flixsterpart2.databinding.ItemMovieBinding

// Constants used for Intents and Logging
const val MOVIE_EXTRA = "MOVIE_EXTRA"
private const val TAG = "MovieAdapter"

/**
 * Adapter for displaying a list of movies in a RecyclerView.
 * @param context Context used for various operations.
 * @param movies List of movies to display.
 */
class MovieAdapter(private val context: Context, private val movies: List<Movie>) :
    RecyclerView.Adapter<MovieAdapter.ViewHolder>() {

    // Inflate the layout for each item and return a ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMovieBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    // Bind data for the movie at the given position
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val movie = movies[position]
        holder.bind(movie)
    }

    // Return the number of movies in the dataset
    override fun getItemCount() = movies.size

    /**
     * ViewHolder class for individual movie items.
     * @param binding ViewBinding instance for the movie item.
     */
    inner class ViewHolder(private val binding: ItemMovieBinding) : RecyclerView.ViewHolder(binding.root),
        View.OnClickListener {

        init {
            // Set an OnClickListener for the whole item view
            binding.root.setOnClickListener(this)
        }

        // Handle item click and navigate to MovieDetailActivity with the selected movie
        override fun onClick(v: View?) {
            val movie = movies[absoluteAdapterPosition]
            val intent = Intent(context, MovieDetailActivity::class.java).apply {
                putExtra(MOVIE_EXTRA, movie)
            }
            context.startActivity(intent)
        }

        /**
         * Bind movie data to the views.
         * @param movie Movie object to be displayed.
         */
        fun bind(movie: Movie) {
            binding.apply {
                // Set the movie title
                mediaTitle.text = movie.title
                // Set the movie rate with a formatted string
                mediaRate.text = context.getString(R.string.rate_label, movie.vote.toString())

                // Load movie poster using Glide with rounded corners
                Glide.with(context)
                    .load("${context.getString(R.string.image_base_url)}${movie.poster_path}")
                    .centerCrop()
                    .transform(RoundedCorners(context.resources.getDimensionPixelSize(R.dimen.rounded_corner_radius)))
                    .into(mediaImage)
            }
        }
    }
}
