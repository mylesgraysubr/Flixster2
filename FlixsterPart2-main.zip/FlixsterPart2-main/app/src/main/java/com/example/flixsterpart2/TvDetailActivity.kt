package com.example.flixsterpart2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.example.flixsterpart2.databinding.DetailTvBinding

private const val TV_TAG = "TvDetailActivity"

class TvDetailActivity : AppCompatActivity() {
    private lateinit var binding: DetailTvBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DetailTvBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val tv = intent.getSerializableExtra(TV_EXTRA) as? Tv
        tv?.let {
            bindTvDetails(it)
        } ?: finish() // Close activity if tv is null
    }

    private fun bindTvDetails(tv: Tv) {
        binding.apply {
            mediaTitle.text = tv.title
            mediaRate.text = getString(R.string.rate_label, tv.vote.toString())
            mediaRateCount.text = getString(R.string.rate_count_label, tv.count.toString())
            mediaReleaseDate.text = getString(R.string.first_air_date_label, tv.release_date)
            mediaOverview.text = getString(R.string.overview_label, tv.overview)

            val imageUrl = getString(R.string.image_base_url) + tv.poster_path
            Glide.with(this@TvDetailActivity)
                .load(imageUrl)
                .centerCrop()
                .transform(RoundedCorners(resources.getDimensionPixelSize(R.dimen.rounded_corner_radius)))
                .into(mediaImage)
        }
    }
}
